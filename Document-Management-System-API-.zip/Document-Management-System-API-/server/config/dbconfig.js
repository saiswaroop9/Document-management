module.exports = {
  db: {
    development: 'mongodb://localhost:27017/dms',
    test: 'mongodb://localhost:27017/dms-test',
  },
  sessionSecret: 'secret',
};
